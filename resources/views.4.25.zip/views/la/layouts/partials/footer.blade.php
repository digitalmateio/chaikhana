@if(!isset($no_padding))
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Powered by <a href="{{url('/')}}">S.S</a>
    </div>
    <strong>Copyright &copy; {{date('Y',time())}}
</footer>
@endif